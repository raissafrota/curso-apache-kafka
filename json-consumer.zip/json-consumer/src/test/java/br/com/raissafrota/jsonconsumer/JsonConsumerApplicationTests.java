package br.com.raissafrota.jsonconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
